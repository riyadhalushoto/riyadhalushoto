import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "../api";

export default function ParentLogin(){

const [email,setEmail] = useState("");
const [password,setPassword] = useState("");
const navigate = useNavigate();

async function handleLogin(){

const res = await apiFetch("/login",{
method:"POST",
body:JSON.stringify({identifier:email,password})
});

const data = await res.json();

if(!res.ok){
alert(data.message);
return;
}

navigate("/parent");
}

return(
<div>
<h2>Parent Login</h2>

<input
placeholder="Email"
value={email}
onChange={e=>setEmail(e.target.value)}
/>

<input
type="password"
placeholder="Password"
value={password}
onChange={e=>setPassword(e.target.value)}
/>

<button onClick={handleLogin}>
Login
</button>

</div>
);
}
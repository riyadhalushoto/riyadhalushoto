import { useAuth } from "../AuthContext";

export default function Parents() {
  const { user } = useAuth();

  return (
    <div style={{ padding: "30px" }}>
      <h2>Parents Management</h2>
      <p>Accessible only if authenticated</p>
      <p>User: {user?.email}</p>
    </div>
  );
}
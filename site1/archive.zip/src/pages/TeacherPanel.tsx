import { useAuth } from "../AuthContext";

export default function TeacherPanel() {
  const { user, logout } = useAuth();

  return (
    <div style={{ padding: "30px" }}>
      <h2>Teacher Panel</h2>
      <p>Welcome {user?.email}</p>

      <ul>
        <li><a href="/grades">Grades</a></li>
        <li><a href="/attendance">Attendance</a></li>
      </ul>

      <button onClick={logout}>Logout</button>
    </div>
  );
}
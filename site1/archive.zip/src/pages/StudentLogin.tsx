import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useNavigate } from "react-router-dom";

export default function StudentLogin() {

  const [studentNumber, setStudentNumber] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  async function handleLogin() {

    try {
      setLoading(true);

      const { data, error } = await supabase
        .from("students")
        .select("*")
        .eq("student_number", studentNumber)
        .single();

      if (error || !data) {
        alert("Numéro étudiant incorrect");
        setLoading(false);
        return;
      }

      if (password !== data.password_hash) {
        alert("Mot de passe incorrect");
        setLoading(false);
        return;
      }

      // ✅ IMPORTANT : on utilise "user"
      localStorage.setItem("user", JSON.stringify(data));

      // Redirection selon rôle
      if (data.role === "admin") navigate("/admin");
      else if (data.role === "teacher") navigate("/teacher");
      else if (data.role === "parent") navigate("/parent");
      else navigate("/student");

    } catch (err) {
      console.log(err);
    }

    setLoading(false);
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>

        <h2 style={{ color: "#d4af37" }}>
          🎓 Connexion Étudiant
        </h2>

        <input
          placeholder="Numéro étudiant"
          value={studentNumber}
          onChange={e => setStudentNumber(e.target.value)}
          style={inputStyle}
        />

        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={e => setPassword(e.target.value)}
          style={inputStyle}
        />

        <button
          onClick={handleLogin}
          disabled={loading}
          style={btnStyle}
        >
          {loading ? "Connexion..." : "Se connecter"}
        </button>

      </div>
    </div>
  );
}

/* STYLES */

const pageStyle: any = {
  minHeight: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "linear-gradient(135deg,#02140f,#063d2d)"
};

const cardStyle: any = {
  background: "#02140f",
  padding: 40,
  borderRadius: 20,
  border: "1px solid #d4af37",
  width: 350,
  textAlign: "center"
};

const inputStyle: any = {
  width: "100%",
  padding: 12,
  marginTop: 20,
  borderRadius: 10
};

const btnStyle: any = {
  marginTop: 25,
  width: "100%",
  padding: 12,
  borderRadius: 10,
  background: "#d4af37",
  border: "none",
  fontWeight: "bold"
};

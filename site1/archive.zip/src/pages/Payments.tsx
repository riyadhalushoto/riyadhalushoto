import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Payments(){

const [payments,setPayments] = useState<any[]>([]);

useEffect(()=>{
load();
},[]);

async function load(){

const res = await apiFetch("/payments");

if(res.ok){
const data = await res.json();
setPayments(data);
}
}

return(
<div style={{padding:30}}>
<h2>💰 Paiements</h2>

{payments.map(p=>(
<div key={p.id}>
<p>Montant : {p.amount} TZS</p>
<p>Date : {p.date}</p>
</div>
))}

</div>
);
}
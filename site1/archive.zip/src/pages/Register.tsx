import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "../api";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleRegister() {
    try {
      setLoading(true);

      await apiFetch("/register", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });

      alert("Inscription réussie !");
      navigate("/login");

    } catch (err: any) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={pageStyle}>
      <div style={formCardStyle}>
        <h2 style={{ textAlign: "center", color: "#d4af37" }}>
          🕌 Inscription Élève
        </h2>

        <input
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          style={inputStyle}
        />

        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={e => setPassword(e.target.value)}
          style={inputStyle}
        />

        <button
          onClick={handleRegister}
          disabled={loading}
          style={btnStyle}
        >
          {loading ? "Inscription..." : "S'enregistrer"}
        </button>
      </div>
    </div>
  );
}

const pageStyle: any = {
  minHeight: "100vh",
  background: "linear-gradient(135deg,#02140f,#063d2d,#02140f)",
  padding: 40,
  color: "white"
};

const formCardStyle: any = {
  maxWidth: 500,
  margin: "auto",
  background: "linear-gradient(145deg,#063d2d,#02140f)",
  padding: 30,
  borderRadius: 25,
  boxShadow: "0 30px 60px rgba(0,0,0,0.6)",
  border: "1px solid #d4af37"
};

const inputStyle: any = {
  padding: 14,
  width: "100%",
  marginTop: 15,
  borderRadius: 12,
  border: "1px solid #d4af37",
  background: "#020617",
  color: "white"
};

const btnStyle: any = {
  marginTop: 25,
  width: "100%",
  padding: 14,
  borderRadius: 12,
  border: "none",
  background: "#d4af37",
  color: "#02140f",
  fontWeight: "bold",
  cursor: "pointer"
};
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function Home(){

const { user, loading } = useAuth();
const navigate = useNavigate();

useEffect(()=>{
if(!loading && user){
if(user.role==="admin") navigate("/admin");
if(user.role==="teacher") navigate("/teacher");
if(user.role==="parent") navigate("/parent");
}
},[user,loading]);

if(loading) return <h2 style={{textAlign:"center"}}>Chargement...</h2>;

return(
<div style={{textAlign:"center",marginTop:120}}>

<h1 style={{fontSize:40}}>
Madrasa Riyadha System
</h1>

<p style={{marginBottom:40}}>
Plateforme sécurisée
</p>

<div style={{display:"flex",justifyContent:"center",gap:20}}>

<button
onClick={()=>navigate("/login")}
style={btn}
>
🔐 Connexion
</button>

<button
onClick={()=>navigate("/register")}
style={btn}
>
📝 Inscription
</button>

</div>

</div>
);
}

const btn:any = {
padding:"14px 30px",
borderRadius:12,
border:"none",
background:"#d4af37",
fontWeight:"bold",
cursor:"pointer"
};
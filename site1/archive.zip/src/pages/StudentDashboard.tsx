import StudentFeed from "./StudentFeed";

export default function StudentDashboard() {

  const user = JSON.parse(localStorage.getItem("user") || "null");

  function logout() {
    localStorage.removeItem("user");
    window.location.href = "/";
  }

  return (
    <div>

      <div style={headerStyle}>
        <h2 style={{ color: "#d4af37" }}>
          🎓 Tableau de Bord Étudiant
        </h2>

        <button onClick={logout} style={logoutBtn}>
          Déconnexion
        </button>
      </div>

      <StudentFeed />

    </div>
  );
}

/* ================= STYLES ================= */

const headerStyle: any = {
  padding: 20,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  background: "#02140f",
  borderBottom: "1px solid #d4af37"
};

const logoutBtn: any = {
  background: "#8b0000",
  color: "white",
  border: "1px solid #d4af37",
  padding: "8px 18px",
  borderRadius: 10,
  cursor: "pointer"
};
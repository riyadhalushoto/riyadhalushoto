import Layout from "../components/Layout";
import { supabase } from "../lib/supabase";
import { useEffect, useState } from "react";

export default function ParentDashboard(){

const user = JSON.parse(localStorage.getItem("student")||"null");

const [children,setChildren] = useState<any[]>([]);

useEffect(()=>{
loadChildren();
},[]);

async function loadChildren(){

if(!user) return;

const { data } = await supabase
.from("students")
.select("*")
.eq("parent_email", user.email);

if(data) setChildren(data);
}

return(
<Layout>

<div style={{padding:40}}>

<h2 style={{color:"#d4af37"}}>
👨‍👩‍👧 Parent Dashboard
</h2>

{children.map(c=>(
<div key={c.id} style={card}>

<h3>{c.first_name} {c.last_name}</h3>
<p>🎓 {c.student_number}</p>

</div>
))}

</div>

</Layout>
);
}

const card:any={
background:"linear-gradient(145deg,#063d2d,#02140f)",
padding:20,
marginTop:20,
borderRadius:20,
border:"1px solid #d4af37"
};
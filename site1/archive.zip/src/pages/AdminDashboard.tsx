import Layout from "../components/Layout";
import StudentsList from "../components/StudentsList";
import PostFeed from "../components/PostFeed";
import { useState } from "react";

export default function AdminDashboard(){

const [tab,setTab] = useState("all");

return(
<Layout>
<div style={{padding:30}}>

<h1 style={{
color:"#d4af37",
marginBottom:40,
letterSpacing:2
}}>
🛠 ADMINISTRATEUR
</h1>

<div style={tabContainer}>

<button onClick={()=>setTab("all")} style={btnStyle(tab==="all")}>
🎓 Étudiants
</button>

<button onClick={()=>setTab("posts")} style={btnStyle(tab==="posts")}>
📢 Publications
</button>

</div>

<div style={contentCard}>
{tab === "all" && <StudentsList />}
{tab === "posts" && <PostFeed />}
</div>

</div>
</Layout>
);
}
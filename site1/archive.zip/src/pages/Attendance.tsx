import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Attendance(){

const [records,setRecords] = useState<any[]>([]);

useEffect(()=>{
load();
},[]);

async function load(){

const res = await apiFetch("/attendance");

if(res.ok){
const data = await res.json();
setRecords(data);
}
}

return(
<div style={{padding:30}}>
<h2>📅 Présence</h2>

{records.map(r=>(
<div key={r.id}>
<p>{r.date} : {r.status}</p>
</div>
))}

</div>
);
}

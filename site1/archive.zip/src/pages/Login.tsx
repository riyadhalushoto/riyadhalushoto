import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "../api";

export default function Login() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleLogin() {
    try {
      setLoading(true);

      const data = await apiFetch("/login", {
        method: "POST",
        body: JSON.stringify({ identifier, password }),
      });

      // Redirection selon rôle
      if (data.role === "admin") navigate("/admin");
      else if (data.role === "teacher") navigate("/teacher");
      else if (data.role === "parent") navigate("/parent");
      if (data.role === "user") navigate("/user");
      else navigate("/");

    } catch (err: any) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={page}>
      <div style={card}>
        <h2 style={title}>🔐 Connexion School System</h2>

        <input
          placeholder="Email"
          value={identifier}
          onChange={e => setIdentifier(e.target.value)}
          style={input}
        />

        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={e => setPassword(e.target.value)}
          style={input}
        />

        <button onClick={handleLogin} style={btn} disabled={loading}>
          {loading ? "Connexion..." : "Se connecter"}
        </button>
      </div>
    </div>
  );
}

const page: any = {
  minHeight: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "radial-gradient(circle at top,#0b3d2e,#06291f)"
};

const card: any = {
  width: 400,
  padding: 40,
  borderRadius: 30,
  background: "linear-gradient(145deg,#063d2d,#02140f)",
  boxShadow: "0 30px 70px rgba(0,0,0,0.6)",
  border: "1px solid #d4af37"
};

const title: any = {
  textAlign: "center",
  color: "#d4af37",
  marginBottom: 35
};

const input: any = {
  width: "100%",
  padding: 14,
  marginBottom: 20,
  borderRadius: 12,
  border: "1px solid #d4af37",
  background: "#020617",
  color: "white"
};

const btn: any = {
  width: "100%",
  padding: 15,
  borderRadius: 12,
  border: "none",
  background: "#d4af37",
  color: "#02140f",
  fontWeight: "bold",
  cursor: "pointer"
};
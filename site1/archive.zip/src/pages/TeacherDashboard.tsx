import { useState } from "react";
import Layout from "../components/Layout";
import Grades from "./Grades";
import Attendance from "./Attendance";

export default function TeacherDashboard(){

const [tab,setTab] = useState("grades");

return(
<Layout>

<div style={container}>

<h1 style={{color:"#d4af37"}}>
👨‍🏫 Teacher Panel
</h1>

<div style={{display:"flex",gap:15,marginBottom:30}}>

<button style={btn(tab==="grades")} onClick={()=>setTab("grades")}>
📝 Notes
</button>

<button style={btn(tab==="attendance")} onClick={()=>setTab("attendance")}>
📅 Attendance
</button>

</div>

{tab==="grades" && <Grades/>}
{tab==="attendance" && <Attendance/>}

</div>

</Layout>
);
}

const container:any = {
padding:40,
maxWidth:1000,
margin:"auto"
};

const btn=(active:boolean)=>({
padding:"12px 20px",
borderRadius:14,
border:"1px solid #d4af37",
background: active ? "#d4af37" : "#02140f",
color: active ? "#02140f" : "#d4af37",
cursor:"pointer"
});
import { useAuth } from "../AuthContext";
import Layout from "../components/Layout";

export default function TeacherPanel(){

const { user } = useAuth();

return(
<Layout>
<div style={{padding:30}}>
<h1>Teacher Panel</h1>
<p>Welcome {user?.email}</p>
</div>
</Layout>
);
}
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function VerifyStudent(){

const { student_number } = useParams();
const [student,setStudent] = useState<any>(null);
const [loading,setLoading] = useState(true);

useEffect(()=>{
verify();
},[]);

async function verify(){

const res = await apiFetch(`/verify/${student_number}`);

if(res.ok){
const data = await res.json();
setStudent(data);
}

setLoading(false);
}

if(loading) return <h2 style={{textAlign:"center"}}>Vérification...</h2>;

if(!student){
return(
<div style={{textAlign:"center",marginTop:100}}>
<h1 style={{color:"red"}}>❌ Carte invalide</h1>
</div>
);
}

return(
<div style={{textAlign:"center",marginTop:80}}>

<h1 style={{color:"#16a34a"}}>✅ Carte valide</h1>

<h2>{student.first_name} {student.last_name}</h2>
<p>Numéro : {student.student_number}</p>
<p>Classe : {student.class_name}</p>

</div>
);
}
import { useEffect, useState } from "react";
import { apiFetch } from "../api.ts";

export default function Grades(){

const [grades,setGrades] = useState<any[]>([]);

useEffect(()=>{
load();
},[]);

async function load(){

const res = await apiFetch("/grades");

if(res.ok){
const data = await res.json();
setGrades(data);
}
}

return(
<div style={{padding:30}}>
<h2>📚 Notes</h2>

{grades.map(g=>(
<div key={g.id}>
<p>{g.subject} : {g.score}</p>
</div>
))}

</div>
);
}

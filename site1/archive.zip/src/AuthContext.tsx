import { createContext, useContext, useEffect, useState } from "react";
import { apiFetch } from "./api";

interface AuthContextType {
  user: any;
  loading: boolean;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: any) => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    try {
      const data = await apiFetch("/profile");
      setUser(data.user);
    } catch {
      setUser(null);
    }
  };

  useEffect(() => {
    const load = async () => {
      await refreshUser();
      setLoading(false);
    };
    load();
  }, []);

  const logout = async () => {
    await apiFetch("/logout", { method: "POST" });
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, refreshUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
};
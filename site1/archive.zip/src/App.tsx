import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminDashboard from "./pages/AdminDashboard";
import ParentLogin from "./pages/ParentLogin";
import Grades from "./pages/Grades";
import Payments from "./pages/Payments";
import Attendance from "./pages/Attendance";
import Parents from "./pages/Parents";
import PaymentSuccess from "./pages/PaymentSuccess";
import TeacherPanel from "./pages/TeacherPanel";
import ParentPanel from "./pages/ParentPanel";
import { ProtectedRoute } from "./ProtectedRoute";

function App(){
return(
<Routes>

<Route path="/" element={<Home/>}/>
<Route path="/login" element={<Login/>}/>
<Route path="/register" element={<Register/>}/>
<Route path="/parent-login" element={<ParentLogin/>}/>

<Route path="/admin" element={
<ProtectedRoute role="admin">
<AdminDashboard/>
</ProtectedRoute>
}/>

<Route path="/grades" element={
<ProtectedRoute>
<Grades/>
</ProtectedRoute>
}/>

<Route path="/payments" element={
<ProtectedRoute>
<Payments/>
</ProtectedRoute>
}/>

<Route path="/attendance" element={
<ProtectedRoute>
<Attendance/>
</ProtectedRoute>
}/>

<Route path="/parents" element={
<ProtectedRoute role="admin">
<Parents/>
</ProtectedRoute>
}/>

<Route path="/teacher" element={
<ProtectedRoute role="teacher">
<TeacherPanel/>
</ProtectedRoute>
}/>

<Route path="/parent" element={
<ProtectedRoute role="parent">
<ParentPanel/>
</ProtectedRoute>
}/>

<Route path="/payment-success" element={<PaymentSuccess/>}/>

</Routes>
);
}

export default App;
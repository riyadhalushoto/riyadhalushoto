export async function apiFetch(path: string, options: any = {}) {
  const res = await fetch(`http://localhost:5000${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.message || "Erreur serveur");
  }

  return data;
}
import { useState } from "react";
import { apiFetch } from "../api";

export default function UglyCardGenerator(){

const [studentNumber,setStudentNumber] = useState("");
const [message,setMessage] = useState("");

async function generate(){

const res = await apiFetch("/admin/generate-card",{
method:"POST",
body:JSON.stringify({student_number:studentNumber})
});

const data = await res.json();

if(res.ok){
setMessage("Carte générée avec succès");
}else{
setMessage(data.message);
}
}

return(
<div>

<h2>💳 Génération Carte</h2>

<input
placeholder="Numéro étudiant"
value={studentNumber}
onChange={e=>setStudentNumber(e.target.value)}
/>

<button onClick={generate}>
Générer
</button>

<p>{message}</p>

</div>
);
}
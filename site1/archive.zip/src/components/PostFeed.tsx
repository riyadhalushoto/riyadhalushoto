import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function PostFeed(){

const [posts,setPosts] = useState<any[]>([]);
const [title,setTitle] = useState("");
const [content,setContent] = useState("");

useEffect(()=>{
loadPosts();
},[]);

async function loadPosts(){
const res = await apiFetch("/posts");
if(res.ok){
const data = await res.json();
setPosts(data);
}
}

async function createPost(){

await apiFetch("/posts",{
method:"POST",
body:JSON.stringify({title,content})
});

setTitle("");
setContent("");
loadPosts();
}

return(
<div>

<h2 style={{color:"#d4af37"}}>📢 Publications</h2>

<input
placeholder="Titre"
value={title}
onChange={e=>setTitle(e.target.value)}
/>

<textarea
placeholder="Contenu"
value={content}
onChange={e=>setContent(e.target.value)}
/>

<button onClick={createPost}>
Publier
</button>

{posts.map(p=>(
<div key={p.id}>
<h3>{p.title}</h3>
<p>{p.content}</p>
</div>
))}

</div>
);
}
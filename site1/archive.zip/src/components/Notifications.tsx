import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function Notifications(){

const [list,setList] = useState<any[]>([]);

useEffect(()=>{ load(); },[]);

async function load(){

const user = JSON.parse(localStorage.getItem("student") || "null");
if(!user) return;

const { data } = await supabase
.from("notifications")
.select("*")
.eq("student_id",user.id)
.order("created_at",{ascending:false});

if(data) setList(data);
}

return(
<div style={wrapper}>
    
<h3 style={title}>🔔 Notifications</h3>

{list.map(n=>(
<div key={n.id} style={card}>
<h4 style={{color:"#d4af37"}}>{n.title}</h4>
<p>{n.message}</p>
</div>
))}

</div>
);
}

/* === STYLE CARTE === */

const wrapper:any = {
marginBottom:30,
padding:25,
background:"linear-gradient(145deg,#063d2d,#02140f)",
borderRadius:25,
border:"1px solid #d4af37",
boxShadow:"0 20px 50px rgba(0,0,0,0.6)"
};

const title:any = {
color:"#d4af37",
marginBottom:20
};

const card:any = {
background:"linear-gradient(145deg,#063d2d,#02140f)",
padding:20,
borderRadius:20,
marginTop:15,
border:"1px solid #d4af37",
boxShadow:"0 15px 40px rgba(0,0,0,0.6)",
transition:"0.4s",
transform:"translateY(0px)"
};
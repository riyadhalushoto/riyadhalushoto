import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function StudentFeed(){

const user = JSON.parse(localStorage.getItem("user") || "null");

const [posts,setPosts] = useState<any[]>([]);
const [likes,setLikes] = useState<any>({});
const [comments,setComments] = useState<any>({});
const [commentInputs,setCommentInputs] = useState<any>({});

useEffect(()=>{
loadPosts();
},[]);

async function loadPosts(){

const { data } = await supabase
.from("publications")
.select("*")
.eq("type","public")
.order("created_at",{ascending:false});

if(data){
setPosts(data);

data.forEach((p:any)=>{
loadLikes(p.id);
loadComments(p.id);
});
}
}

/* ================= LIKES ================= */

async function loadLikes(postId:string){

const { count } = await supabase
.from("likes")
.select("*",{count:"exact",head:true})
.eq("post_id",postId);

setLikes((prev:any)=>({...prev,[postId]:count || 0}));
}

async function toggleLike(postId:string){

if(!user){
alert("Connectez-vous pour liker");
return;
}

const { data:existing } = await supabase
.from("likes")
.select("*")
.eq("post_id",postId)
.eq("student_id",user.id)
.single();

if(existing){

await supabase
.from("likes")
.delete()
.eq("id",existing.id);

}else{

await supabase
.from("likes")
.insert({
post_id:postId,
student_id:user.id
});
}

loadLikes(postId);
}

/* ================= COMMENTS ================= */

async function loadComments(postId:string){

const { data } = await supabase
.from("comments")
.select(`
*,
students(first_name,last_name,photo_url)
`)
.eq("post_id",postId)
.order("created_at",{ascending:true});

setComments((prev:any)=>({
...prev,
[postId]:data || []
}));
}

async function addComment(postId:string){

if(!user){
alert("Connectez-vous pour commenter");
return;
}

const text = commentInputs[postId];
if(!text) return;

await supabase
.from("comments")
.insert({
post_id:postId,
student_id:user.id,
content:text
});

setCommentInputs((prev:any)=>({...prev,[postId]:""}));
loadComments(postId);
}

/* ================= UI ================= */

return(
<div style={pageStyle}>

{posts.map(post=>(
<div key={post.id} style={postCardStyle}>

<h2 style={titleStyle}>{post.title}</h2>

<p style={contentStyle}>{post.content}</p>

{post.media_url && (
<img
src={post.media_url}
style={mediaStyle}
/>
)}

<div style={{display:"flex",gap:15,marginTop:20}}>

<button onClick={()=>toggleLike(post.id)} style={likeBtn}>
❤️ {likes[post.id] || 0}
</button>

</div>

<div style={{marginTop:20}}>

<input
placeholder="Ajouter un commentaire..."
value={commentInputs[post.id] || ""}
onChange={e=>setCommentInputs(prev=>({
...prev,
[post.id]:e.target.value
}))}
style={commentInput}
/>

<button onClick={()=>addComment(post.id)} style={sendBtn}>
Envoyer
</button>

</div>

<div style={{marginTop:25}}>

{comments[post.id]?.map((c:any)=>(
<div key={c.id} style={commentRow}>

{c.students?.photo_url && (
<img
src={c.students.photo_url}
style={avatarStyle}
/>
)}

<p>
<b style={{color:"#d4af37"}}>
{c.students?.first_name} {c.students?.last_name}
</b>
: {c.content}
</p>

</div>
))}

</div>

</div>
))}

</div>
);
}

/* ================= STYLES ================= */

const pageStyle:any = {
maxWidth:900,
margin:"auto",
padding:30,
color:"white"
};

const postCardStyle:any = {
background:"linear-gradient(145deg,#063d2d,#02140f)",
padding:30,
marginBottom:50,
borderRadius:25,
border:"1px solid #d4af37"
};

const titleStyle:any = { color:"#d4af37", marginBottom:15 };
const contentStyle:any = { lineHeight:1.7 };
const mediaStyle:any = { width:"100%", borderRadius:20, marginTop:20 };
const likeBtn:any = { background:"#d4af37", padding:"8px 18px", borderRadius:12 };
const commentInput:any = { width:"100%", padding:12, borderRadius:12 };
const sendBtn:any = { marginTop:10, padding:"6px 14px", borderRadius:10 };
const commentRow:any = { display:"flex", gap:12, marginTop:10 };
const avatarStyle:any = { width:35, height:35, borderRadius:"50%" };
import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function StudentsList(){

const [students,setStudents] = useState<any[]>([]);

useEffect(()=>{
loadStudents();
},[]);

async function loadStudents(){
const res = await apiFetch("/students");
if(res.ok){
const data = await res.json();
setStudents(data);
}
}

async function deleteStudent(id:string){

if(!confirm("Supprimer étudiant ?")) return;

await apiFetch(`/students/${id}`,{
method:"DELETE"
});

loadStudents();
}

return(
<div>

<h2 style={{color:"#d4af37"}}>
🎓 LISTE OFFICIELLE DES ÉTUDIANTS
</h2>

{students.map(s=>(
<div key={s.id}>
<h3>{s.first_name} {s.last_name}</h3>
<p>{s.student_number}</p>
<button onClick={()=>deleteStudent(s.id)}>Supprimer</button>
</div>
))}

</div>
);
}

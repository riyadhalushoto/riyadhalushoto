import { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Analytics(){

const [stats,setStats] = useState<any>(null);

useEffect(()=>{
loadStats();
},[]);

async function loadStats(){

const res = await apiFetch("/admin/analytics");

if(res.ok){
const data = await res.json();
setStats(data);
}
}

if(!stats) return <p>Chargement analytics...</p>;

return(
<div>

<h2 style={{color:"#d4af37"}}>📊 Analytics</h2>

<p>Total Étudiants : {stats.totalStudents}</p>
<p>Total Parents : {stats.totalParents}</p>
<p>Total Teachers : {stats.totalTeachers}</p>
<p>Total Paiements : {stats.totalPayments}</p>

</div>
);
}
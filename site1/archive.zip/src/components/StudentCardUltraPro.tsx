import { useEffect, useState, useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

export default function StudentCardBank(){

const [student,setStudent] = useState<any>(null);
const [flip,setFlip] = useState(false);

const frontRef = useRef<HTMLDivElement>(null);
const backRef = useRef<HTMLDivElement>(null);

useEffect(()=>{
const data = localStorage.getItem("student");
if(data){
setStudent(JSON.parse(data));
}
},[]);

if(!student) return null;

const verifyURL = `${window.location.origin}/verify?student=${student.student_number}`;


/* ================= DOWNLOAD PNG ================= */

async function downloadPNG(){

if(!frontRef.current || !backRef.current) return;

const frontCanvas = await html2canvas(frontRef.current,{scale:4,useCORS:true});
const backCanvas = await html2canvas(backRef.current,{scale:4,useCORS:true});

const finalCanvas = document.createElement("canvas");

finalCanvas.width = frontCanvas.width;
finalCanvas.height = frontCanvas.height * 2;

const ctx = finalCanvas.getContext("2d");
if(!ctx) return;

ctx.drawImage(frontCanvas,0,0);
ctx.drawImage(backCanvas,0,frontCanvas.height);

const link = document.createElement("a");
link.download = "student_card_recto_verso.png";
link.href = finalCanvas.toDataURL("image/png");
link.click();
}


/* ================= DOWNLOAD PDF ================= */

async function downloadPDF(){

if(!frontRef.current || !backRef.current) return;

const frontCanvas = await html2canvas(frontRef.current,{scale:4,useCORS:true});
const backCanvas = await html2canvas(backRef.current,{scale:4,useCORS:true});

const frontImg = frontCanvas.toDataURL("image/png");
const backImg = backCanvas.toDataURL("image/png");

const pdf = new jsPDF({
orientation:"landscape",
unit:"px",
format:[380,220]
});

pdf.addImage(frontImg,"PNG",0,0,380,220);
pdf.addPage();
pdf.addImage(backImg,"PNG",0,0,380,220);

pdf.save("student_card_recto_verso.pdf");
}


/* ================= UI ================= */

return(
<div style={{
display:"flex",
flexDirection:"column",
alignItems:"center",
marginTop:100
}}>

{/* ===== ANIMATION CARD ===== */}

<div
onClick={()=>setFlip(!flip)}
style={{perspective:"1000px",cursor:"pointer"}}
>

<div
style={{
width:380,
height:220,
position:"relative",
transformStyle:"preserve-3d",
transition:"0.8s",
transform: flip ? "rotateY(180deg)" : "rotateY(0deg)"
}}
>

/* ===== FRONT ===== */

<div style={{
position:"absolute",
width:"100%",
height:"100%",
backfaceVisibility:"hidden",
borderRadius:20,
background:"linear-gradient(135deg,#000000,#1c1c1c)",
color:"#d4af37",
padding:20,
boxShadow:"0 20px 50px rgba(0,0,0,0.7)",
fontFamily:"monospace"
}}>

<h3 style={{margin:0}}>Madrasa Riyadha Lushoto</h3>

{student.photo_url && (
<div style={{
position:"absolute",
top:60,
right:20,
width:80,
height:95,
borderRadius:12,
overflow:"hidden",
border:"2px solid #d4af37",
boxShadow:"0 5px 15px rgba(0,0,0,0.6)"
}}>
<img
src={student.photo_url}
crossOrigin="anonymous"
style={{
width:"100%",
height:"100%",
objectFit:"cover"
}}
/>
</div>
)}

<div style={{marginTop:20}}>

<h2 style={{letterSpacing:2}}>
{student.first_name} {student.middle_name}
</h2>

<p>{student.last_name}</p>

<p style={{fontSize:12}}>
N° Étudiant : {student.student_number}
</p>

<p style={{fontSize:12}}>
Naissance : {student.dob}
</p>

<p style={{fontSize:12}}>
Nationalité : {student.nationality}
</p>

<p style={{fontSize:12}}>
ID / Passeport : {student.national_id}
</p>

</div>

</div>


/* ===== BACK ===== */

<div style={{
position:"absolute",
width:"100%",
height:"100%",
backfaceVisibility:"hidden",
transform:"rotateY(180deg)",
borderRadius:20,
background:"#111",
color:"#fff",
padding:20,
fontFamily:"monospace"
}}>

<div style={{
height:40,
background:"#000",
marginBottom:20,
borderRadius:5
}}/>

<p style={{fontSize:12}}>
Adresse : {student.residence_country} - {student.residence_region}
</p>

<p style={{fontSize:12}}>
Téléphone : {student.phone}
</p>

<p style={{fontSize:12}}>
Email : {student.email}
</p>

<div style={{marginTop:20}}>
<QRCodeCanvas value={verifyURL} size={90}/>
</div>

</div>

</div>
</div>


{/* ===== DOWNLOAD BUTTONS ===== */}

<div style={{display:"flex",gap:15,marginTop:30}}>

<button
onClick={downloadPNG}
style={{
padding:"10px 20px",
borderRadius:10,
border:"none",
background:"#d4af37",
fontWeight:"bold"
}}
>
⬇ PNG Recto/Verso
</button>

<button
onClick={downloadPDF}
style={{
padding:"10px 20px",
borderRadius:10,
border:"none",
background:"#145a32",
color:"white",
fontWeight:"bold"
}}
>
⬇ PDF Recto/Verso
</button>

</div>

</div>
);
}
import { ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function Layout({ children }: { children: ReactNode }) {

const { user, logout } = useAuth();
const navigate = useNavigate();

async function handleLogout(){
await logout();
navigate("/");
}

return (
<div style={page}>

<div style={navbar}>

<h2 style={logoStyle}>
🕌 Madrasa Riyadha Lushoto
</h2>

<div style={{display:"flex",gap:18,alignItems:"center",flexWrap:"wrap"}}>

<Link to="/">
<button style={navBtn}>🏠 Home</button>
</Link>

{user && (
<>
<Link to="/grades"><button style={navBtn}>📝 Notes</button></Link>
<Link to="/attendance"><button style={navBtn}>📅 Attendance</button></Link>
<Link to="/payments"><button style={navBtn}>💳 Paiements</button></Link>
</>
)}

{user?.role === "admin" && (
<Link to="/admin">
<button style={adminBtn}>⚙ Admin Panel</button>
</Link>
)}

{user && (
<button onClick={handleLogout} style={logoutBtn}>
Déconnexion
</button>
)}

</div>
</div>

<div style={content}>
{children}
</div>

</div>
);
}

/* Styles inchangés */
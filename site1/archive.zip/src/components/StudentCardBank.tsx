import { useState, useRef } from "react";
import { apiFetch } from "../api";
import { QRCodeCanvas } from "qrcode.react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

export default function StudentCardBank() {

const [number,setNumber] = useState("");
const [student,setStudent] = useState<any>(null);
const [flip,setFlip] = useState(false);

const frontRef = useRef<HTMLDivElement>(null);
const backRef = useRef<HTMLDivElement>(null);

/* ================= SEARCH VIA BACKEND ================= */

async function search(){
const res = await apiFetch(`/students/number/${number}`);

if(res.ok){
const data = await res.json();
setStudent(data);
}else{
alert("Étudiant introuvable");
}
}

if(!student){
return(
<div style={{padding:40,textAlign:"center"}}>
<h2>🔎 Recherche Étudiant</h2>
<input
placeholder="Numéro étudiant"
style={{padding:12,width:250,borderRadius:8}}
onChange={e=>setNumber(e.target.value)}
/>
<button
onClick={search}
style={{marginLeft:10,padding:"12px 20px",borderRadius:8}}
>
Rechercher
</button>
</div>
);
}

/* ================= QR SÉCURISÉ ================= */

const verifyURL = `${window.location.origin}/verify/${student.student_number}`;

/* ================= PDF ================= */

async function downloadPDF(){
if(!frontRef.current || !backRef.current) return;

const frontCanvas = await html2canvas(frontRef.current,{scale:4,useCORS:true});
const backCanvas = await html2canvas(backRef.current,{scale:4,useCORS:true});

const pdf = new jsPDF({
orientation:"landscape",
unit:"mm",
format:[85.6,53.98]
});

pdf.addImage(frontCanvas.toDataURL("image/png"),"PNG",0,0,85.6,53.98);
pdf.addPage();
pdf.addImage(backCanvas.toDataURL("image/png"),"PNG",0,0,85.6,53.98);

pdf.save(`MRL-${student.student_number}.pdf`);
}

/* UI simplifiée conservée */
return(
<div style={{display:"flex",flexDirection:"column",alignItems:"center",marginTop:80}}>

<div ref={frontRef}>
<h2>{student.first_name} {student.last_name}</h2>
<p>{student.student_number}</p>
</div>

<div ref={backRef}>
<QRCodeCanvas value={verifyURL} size={85}/>
</div>

<button onClick={downloadPDF}>
⬇ Download Official PDF
</button>

</div>
);
}
import { useEffect, useState, useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

export default function StudentCardBank(){

const [student,setStudent] = useState<any>(null);
const [flip,setFlip] = useState(false);

const frontRef = useRef<HTMLDivElement>(null);
const backRef = useRef<HTMLDivElement>(null);

useEffect(()=>{
const data = localStorage.getItem("student");
if(data){
setStudent(JSON.parse(data));
}
},[]);

if(!student) return null;

const verifyURL = `${window.location.origin}/verify?student=${student.student_number}`;



// ================= PNG RECTO VERSO =================
async function downloadPNG(){

if(!frontRef.current || !backRef.current) return;

const frontCanvas = await html2canvas(frontRef.current,{scale:4,useCORS:true});
const backCanvas = await html2canvas(backRef.current,{scale:4,useCORS:true});

const finalCanvas = document.createElement("canvas");
finalCanvas.width = frontCanvas.width;
finalCanvas.height = frontCanvas.height * 2;

const ctx = finalCanvas.getContext("2d");
if(!ctx) return;

ctx.drawImage(frontCanvas,0,0);
ctx.drawImage(backCanvas,0,frontCanvas.height);

const link = document.createElement("a");
link.download = "student_card_recto_verso.png";
link.href = finalCanvas.toDataURL("image/png");
link.click();
}



// ================= PDF RECTO VERSO =================
async function downloadPDF(){

if(!frontRef.current || !backRef.current) return;

const frontCanvas = await html2canvas(frontRef.current,{scale:4,useCORS:true});
const backCanvas = await html2canvas(backRef.current,{scale:4,useCORS:true});

const frontImg = frontCanvas.toDataURL("image/png");
const backImg = backCanvas.toDataURL("image/png");

const pdf = new jsPDF({
orientation:"landscape",
unit:"px",
format:[380,220]
});

pdf.addImage(frontImg,"PNG",0,0,380,220);
pdf.addPage();
pdf.addImage(backImg,"PNG",0,0,380,220);

pdf.save("student_card_recto_verso.pdf");
}



return(
<div style={{
display:"flex",
flexDirection:"column",
alignItems:"center",
marginTop:100
}}>

{/* ================= CARTE ANIMÉE ================= */}
<div
onClick={()=>setFlip(!flip)}
style={{perspective:"1000px",cursor:"pointer"}}
>

<div
style={{
width:380,
height:220,
position:"relative",
transformStyle:"preserve-3d",
transition:"transform 0.8s",
transform: flip ? "rotateY(180deg)" : "rotateY(0deg)"
}}
>

{/* FRONT */}
<div style={{
position:"absolute",
width:"100%",
height:"100%",
backfaceVisibility:"hidden",
borderRadius:20,
background:"linear-gradient(135deg,#000000,#1c1c1c)",
color:"#d4af37",
padding:20,
boxShadow:"0 20px 50px rgba(0,0,0,0.7)",
fontFamily:"monospace"
}}>

<h3 style={{margin:0}}>Madrasa Riyadha Lushoto</h3>

{student.photo_url && (
<img
crossOrigin="anonymous"
src={student.photo_url}
style={{
width:70,
height:70,
borderRadius:10,
objectFit:"cover",
marginTop:10,
border:"2px solid #d4af37"
}}
/>
)}

<div style={{marginTop:15}}>
<h2 style={{letterSpacing:3}}>
{student.student_number}
</h2>
<p>{student.first_name} {student.last_name}</p>
<p style={{fontSize:12}}>Valid Student</p>
</div>

</div>

{/* BACK */}
<div style={{
position:"absolute",
width:"100%",
height:"100%",
backfaceVisibility:"hidden",
transform:"rotateY(180deg)",
borderRadius:20,
background:"#111",
color:"#fff",
padding:20,
fontFamily:"monospace"
}}>

<div style={{
height:40,
background:"#000",
marginBottom:20,
borderRadius:5
}}/>

<p style={{fontSize:12}}>
This card remains property of Madrasa Riyadha Lushoto.
</p>

<QRCodeCanvas value={verifyURL} size={90} />

</div>

</div>
</div>


{/* ================= EXPORT FRONT (INVISIBLE) ================= */}
<div
ref={frontRef}
style={{
position:"absolute",
left:"-9999px",
top:0,
width:380,
height:220,
borderRadius:20,
background:"linear-gradient(135deg,#000000,#1c1c1c)",
color:"#d4af37",
padding:20,
fontFamily:"monospace"
}}
>

<h3 style={{margin:0}}>Madrasa Riyadha Lushoto</h3>

{student.photo_url && (
<img
crossOrigin="anonymous"
src={student.photo_url}
style={{
width:70,
height:70,
borderRadius:10,
objectFit:"cover",
marginTop:10,
border:"2px solid #d4af37"
}}
/>
)}

<div style={{marginTop:15}}>
<h2 style={{letterSpacing:3}}>
{student.student_number}
</h2>
<p>{student.first_name} {student.last_name}</p>
<p style={{fontSize:12}}>Valid Student</p>
</div>

</div>



{/* ================= EXPORT BACK (INVISIBLE) ================= */}
<div
ref={backRef}
style={{
position:"absolute",
left:"-9999px",
top:250,
width:380,
height:220,
borderRadius:20,
background:"#111",
color:"#fff",
padding:20,
fontFamily:"monospace"
}}
>

<div style={{
height:40,
background:"#000",
marginBottom:20,
borderRadius:5
}}/>

<p style={{fontSize:12}}>
This card remains property of Madrasa Riyadha Lushoto.
</p>

<QRCodeCanvas value={verifyURL} size={90} />

</div>


<br/>

<div style={{display:"flex",gap:15}}>

<button
onClick={downloadPNG}
style={{
padding:"10px 20px",
borderRadius:10,
border:"none",
background:"#d4af37",
color:"#000",
fontWeight:"bold",
cursor:"pointer"
}}
>
⬇ PNG Recto/Verso
</button>

<button
onClick={downloadPDF}
style={{
padding:"10px 20px",
borderRadius:10,
border:"none",
background:"#145a32",
color:"#fff",
fontWeight:"bold",
cursor:"pointer"
}}
>
⬇ PDF Recto/Verso
</button>

</div>

<p style={{marginTop:10,fontSize:12,opacity:0.6}}>
Clique sur la carte pour voir le verso
</p>

</div>
);
}